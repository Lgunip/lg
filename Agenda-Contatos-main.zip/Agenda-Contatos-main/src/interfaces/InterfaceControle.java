
package interfaces;

public interface InterfaceControle {
    public void salvarControle(Object... valor);
    public void excluirControle(int id);
    public void carregarComboBox();
}
