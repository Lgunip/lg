package visao;

public class ContatoVisao extends FormPadrao {
    
    public ContatoVisao(){
        setTitle("Contatos");
    }

    @Override
    public void inicializarComponentes() {
        
    }

    @Override
    public void salvarVisao() {
        
    }
}
